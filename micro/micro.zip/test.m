begin
    A := 111; -- this is a comment
    B := A + (112 - 111);
    -- this is another comment
    B := B + 111;
    write (A,B);
    read (A,B,C);
    write (A+100, B+100);
end

