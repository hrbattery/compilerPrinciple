begin 
  read(a);
  a := a + 1;
  c := a + 1;
  write(a, c, a + c);
end